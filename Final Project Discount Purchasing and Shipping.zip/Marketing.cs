﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Final_Project_Discount_Purchasing_and_Shipping
{
    internal class Marketing : Item, ICostInterface
    {
        decimal cartDiscount;
        decimal wholeCartDiscount;
        decimal totalCartDiscount;
        decimal straightCost;
        decimal totalVolumeDiscount;
        decimal volumeDiscount;
        decimal appliedDiscount;
        // constructor
        public Marketing(string id, string name, decimal price, int quantity, int tier1, int tier2, int tier3,
            int volume1, int volume2, int volume3, decimal cartDiscount)
            : base(id, name, price, quantity, tier1, tier2, tier3, volume1, volume2, volume3)
        {
            this.cartDiscount = cartDiscount;
        }
        // getters
        public decimal getTotalCartDiscount() { return totalCartDiscount; }
        public decimal getTotalVolumeDiscount() { return totalVolumeDiscount; }
        public decimal getStrightCost() { return straightCost; }
        // setters
        public void setTotalCartDiscount(decimal totalCartDiscount)
        {
            this.totalCartDiscount = totalCartDiscount;
        }
        public void setTotalVolumeDiscount(decimal totalVolumeDiscount)
        {
            this.totalVolumeDiscount = totalVolumeDiscount;
        }
        public void setStraightCost(decimal straightCost)
        {
            this.straightCost = straightCost;
        }
        // interface methods
        public void discountMethod()
        {
            decimal noDiscount = getQuantity() * getPrice();
            WriteLine($"Cost with no discount: {noDiscount:C}");
            // tier calculation
            if (getQuantity() > getVolume1())
            {
                volumeDiscount = (decimal)getTier1() / 100;
                volumeDiscount = volumeDiscount * noDiscount;
                wholeCartDiscount = noDiscount * 0.1m;
                cartDiscount = noDiscount - wholeCartDiscount;
                WriteLine($"Volume rate: {getTier1():N} %, discount: {volumeDiscount:C}");
                appliedDiscount = noDiscount - volumeDiscount;
                WriteLine($"Cost after Volume discount: {appliedDiscount:C}");
                // calculations for summary report
                setStraightCost(straightCost + noDiscount);
                setTotalVolumeDiscount(totalVolumeDiscount + volumeDiscount);
                setTotalCartDiscount(totalCartDiscount + cartDiscount);

            }
            else if (getQuantity() > getVolume2())
            {
                volumeDiscount = (decimal)getTier2() / 100;
                volumeDiscount = volumeDiscount * noDiscount;
                wholeCartDiscount = noDiscount * 0.1m;
                cartDiscount = noDiscount - wholeCartDiscount;
                WriteLine($"Volume rate: {getTier2():N} %, discount: {volumeDiscount:C}");
                appliedDiscount = noDiscount - volumeDiscount;
                WriteLine($"Cost after Volume discount: {appliedDiscount:C}");
                setStraightCost(straightCost + noDiscount);
                setTotalVolumeDiscount(totalVolumeDiscount + volumeDiscount);
                setTotalCartDiscount(totalCartDiscount + cartDiscount);
            }
            else if (getQuantity() > getVolume3())
            {
                volumeDiscount = (decimal)getTier3() / 100;
                volumeDiscount = volumeDiscount * noDiscount;
                wholeCartDiscount = noDiscount * 0.1m;
                cartDiscount = noDiscount - wholeCartDiscount;
                WriteLine($"Volume rate: {getTier3():N} %, discount: {volumeDiscount:C}");
                appliedDiscount = noDiscount - volumeDiscount;
                WriteLine($"Cost after Volume discount: {appliedDiscount:C}");
                setStraightCost(getStrightCost() + noDiscount);
                setTotalVolumeDiscount(getTotalVolumeDiscount() + volumeDiscount);
                setTotalCartDiscount(getTotalCartDiscount() + cartDiscount);
            }
            else
            {
                WriteLine("Not enough volume was purchased. No discount.");
            }
            WriteLine($"Whole cart discount: {wholeCartDiscount:C}");
            WriteLine($"Cost after cart discount: {cartDiscount:C}\n");
        }
        // whole cart discount
        public void summaryMethod()
        {
            WriteLine("Part A Summary:");
            WriteLine($"Straight Cost: {straightCost:C}");
            WriteLine($"Volume Discount: {totalVolumeDiscount:C}");
            WriteLine($"Cart Discount: {totalCartDiscount:C}\n");
        }
    }
}
